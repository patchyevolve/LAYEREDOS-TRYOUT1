#include "kernel.h"
#include "pmm.h"
#include "hal.h"
#include "eventbus.h"
#include "sched.h"
#include "process.h"
#include "work.h"
#include "kmalloc.h"
#include "sync.h"

#define PMM_PERCPU_CACHE_SIZE 32

typedef struct free_page {
    struct free_page* next;
} free_page_t;

/* Global free list (protected by pmm_global_lock) */
static free_page_t*  free_list = NULL;
static uint64_t      total_page_count = 0;
static uint64_t      global_free_count = 0;
static uint64_t      total_memory = 0;

static uint64_t      bitmap_base = 0;
static uint64_t      bitmap_pages = 0;
static uint8_t*      used_bitmap;

static spinlock_t    pmm_global_lock;
static work_item_t   oom_work_item;
static volatile int  oom_scheduled = 0;

/* Per-CPU caches: each CPU has a small stash of pages.
 * Pages in per-CPU cache have bitmap SET (considered in-use by the PMM
 * system).  When flushed back to the global list the bitmap is cleared.
 * pmm_free_pages_count() reports the sum across all CPUs + global list.
 */
static uint64_t      cpu_cache[MAX_CPUS][PMM_PERCPU_CACHE_SIZE];
static int           cpu_cache_count[MAX_CPUS];
static spinlock_t    cpu_cache_lock[MAX_CPUS];

/* ------------------------------------------------------------------ */
/*  OOM handling                                                      */
/* ------------------------------------------------------------------ */
static void pmm_oom_kill_worker(void* arg) {
    (void)arg;
    kprintf("[OOM] Out of memory! Killing current process...\n");
    eventbus_publish(EV_OOM_KILL, 0, 0, 0, 0);
    if (current_thread && current_thread->proc) {
        process_exit(current_thread->proc, -12);
        thread_exit(-12);
    }
    oom_scheduled = 0;
}

static void pmm_oom_kill(void) {
    if (!oom_scheduled) {
        kmalloc_compact();
        oom_scheduled = 1;
        oom_work_item.func = pmm_oom_kill_worker;
        oom_work_item.data = NULL;
        work_queue_schedule(&system_wq, &oom_work_item);
    }
}

/* ------------------------------------------------------------------ */
/*  Bitmap helpers                                                    */
/* ------------------------------------------------------------------ */
static void bitmap_set(uint64_t page_idx) {
    used_bitmap[page_idx / 8] |= (1 << (page_idx % 8));
}
static void bitmap_clear(uint64_t page_idx) {
    used_bitmap[page_idx / 8] &= ~(1 << (page_idx % 8));
}
static int bitmap_test(uint64_t page_idx) {
    return (used_bitmap[page_idx / 8] >> (page_idx % 8)) & 1;
}

/* ------------------------------------------------------------------ */
/*  Per-CPU cache helpers                                             */
/* ------------------------------------------------------------------ */
static int current_cpu(void) {
    return smp_cpu_id();
}

/* Try to pop a page from the current CPU's cache.  Returns 0 if empty. */
static uint64_t cache_try_pop(void) {
    int cpu = current_cpu();
    cpu_flags_t flags;
    spinlock_acquire(&cpu_cache_lock[cpu], &flags);
    int n = cpu_cache_count[cpu];
    if (n <= 0) {
        spinlock_release(&cpu_cache_lock[cpu], flags);
        return 0;
    }
    n--;
    uint64_t phys = cpu_cache[cpu][n];
    cpu_cache_count[cpu] = n;
    spinlock_release(&cpu_cache_lock[cpu], flags);
    return phys;
}

/* Try to push a page to the current CPU's cache.  Returns 1 on success,
 * 0 if the cache is full (caller must flush). */
static int cache_try_push(uint64_t phys) {
    int cpu = current_cpu();
    cpu_flags_t flags;
    spinlock_acquire(&cpu_cache_lock[cpu], &flags);
    int n = cpu_cache_count[cpu];
    if (n >= PMM_PERCPU_CACHE_SIZE) {
        spinlock_release(&cpu_cache_lock[cpu], flags);
        return 0;
    }
    cpu_cache[cpu][n] = phys;
    cpu_cache_count[cpu] = n + 1;
    spinlock_release(&cpu_cache_lock[cpu], flags);
    return 1;
}

/* Flush the oldest N/2 pages from the current CPU's cache back to the
 * global free list.  Must hold pmm_global_lock. */
static void cache_flush_half(void) {
    int cpu = current_cpu();
    cpu_flags_t flags;
    spinlock_acquire(&cpu_cache_lock[cpu], &flags);
    int n = cpu_cache_count[cpu];
    int keep = n / 2;
    for (int i = keep; i < n; i++) {
        uint64_t flush_phys = cpu_cache[cpu][i];
        uint64_t fidx = flush_phys / PAGE_SIZE;
        if (fidx < total_page_count) {
            bitmap_clear(fidx);
            global_free_count++;
            free_page_t* fp = (free_page_t*)PHYS_TO_VIRT(flush_phys);
            fp->next = free_list;
            free_list = fp;
        }
    }
    cpu_cache_count[cpu] = keep;
    spinlock_release(&cpu_cache_lock[cpu], flags);
}

/* Refill the current CPU's cache from the global free list (up to
 * capacity).  Must hold pmm_global_lock.  Returns the number of pages
 * placed into the cache. */
static int cache_refill(void) {
    int cpu = current_cpu();
    cpu_flags_t flags;
    spinlock_acquire(&cpu_cache_lock[cpu], &flags);
    int count = 0;
    int cap = PMM_PERCPU_CACHE_SIZE;
    while (free_list && count < cap) {
        free_page_t* page = free_list;
        uint64_t phys = VIRT_TO_PHYS(page);
        uint64_t idx = phys / PAGE_SIZE;
        if ((phys & 0xFFF) || idx >= total_page_count) break;
        free_list = page->next;
        global_free_count--;
        bitmap_set(idx);
        cpu_cache[cpu][count++] = phys;
    }
    cpu_cache_count[cpu] = count;
    spinlock_release(&cpu_cache_lock[cpu], flags);
    return count;
}

/* Steal up to PMM_PERCPU_CACHE_SIZE/2 pages from another CPU's cache.
 * Must hold pmm_global_lock.  Returns number stolen or 0. */
static int cache_steal(int victim_cpu) {
    if (victim_cpu == current_cpu()) return 0;
    cpu_flags_t flags;
    spinlock_acquire(&cpu_cache_lock[victim_cpu], &flags);
    int n = cpu_cache_count[victim_cpu];
    int steal = n / 2;
    if (steal <= 0) {
        spinlock_release(&cpu_cache_lock[victim_cpu], flags);
        return 0;
    }
    /* Move stolen pages from victim's cache to our cache.
     * Bitmap stays SET throughout — pages just change ownership. */
    int my_cpu = current_cpu();
    cpu_cache_count[victim_cpu] = n - steal;
    spinlock_release(&cpu_cache_lock[victim_cpu], flags);

    /* Now add them to our cache */
    spinlock_acquire(&cpu_cache_lock[my_cpu], &flags);
    int my_n = cpu_cache_count[my_cpu];
    int room = PMM_PERCPU_CACHE_SIZE - my_n;
    if (room > steal) room = steal;
    for (int i = 0; i < room; i++) {
        cpu_cache[my_cpu][my_n + i] = cpu_cache[victim_cpu][n - steal + i];
    }
    cpu_cache_count[my_cpu] = my_n + room;
    spinlock_release(&cpu_cache_lock[my_cpu], flags);
    return room;
}

/* ------------------------------------------------------------------ */
/*  Public API                                                        */
/* ------------------------------------------------------------------ */
uint64_t pmm_total_pages(void) { return total_page_count; }

uint64_t pmm_free_pages_count(void) {
    /* Sum global free list + all per-CPU caches */
    uint64_t total = global_free_count;
    for (int i = 0; i < MAX_CPUS; i++) {
        total += cpu_cache_count[i];
    }
    return total;
}

uint64_t pmm_used_pages(void) {
    uint64_t free_sum = global_free_count;
    for (int i = 0; i < MAX_CPUS; i++) {
        free_sum += cpu_cache_count[i];
    }
    return total_page_count - free_sum;
}

void pmm_mark_region_used(uint64_t start, uint64_t end) {
    uint64_t sp = start / PAGE_SIZE;
    uint64_t ep = (end + PAGE_SIZE - 1) / PAGE_SIZE;
    for (uint64_t i = sp; i < ep && i < total_page_count; i++) {
        if (!bitmap_test(i)) {
            bitmap_set(i);
            global_free_count--;
        }
    }
}

uint64_t pmm_alloc_page(void) {
    /* Fast path: try per-CPU cache */
    uint64_t phys = cache_try_pop();
    if (phys) {
        kmemset((void*)PHYS_TO_VIRT(phys), 0, PAGE_SIZE);
        return phys;
    }

    /* Slow path: refill from global */
    cpu_flags_t flags;
    spinlock_acquire(&pmm_global_lock, &flags);

    if (!free_list) {
        /* Try stealing from other CPUs */
        int nr = smp_nr_cpus();
        for (int cpu = 0; cpu < nr; cpu++) {
            if (cache_steal(cpu)) {
                /* Stole some pages into our cache — pop one */
                spinlock_release(&pmm_global_lock, flags);
                phys = cache_try_pop();
                if (phys) {
                    kmemset((void*)PHYS_TO_VIRT(phys), 0, PAGE_SIZE);
                    return phys;
                }
                spinlock_acquire(&pmm_global_lock, &flags);
            }
        }
        spinlock_release(&pmm_global_lock, flags);
        pmm_oom_kill();
        return 0;
    }

    /* Pop one page from global free list */
    free_page_t* page = free_list;
    phys = VIRT_TO_PHYS(page);
    uint64_t idx = phys / PAGE_SIZE;

    if (phys & 0xFFF) {
        kprintf("[PMM] CRASH: free-list corruption! phys=%lx (misaligned)\n", phys);
        for (;;) asm("cli; hlt");
    }
    if (idx >= total_page_count) {
        kprintf("[PMM] CRASH: free-list corruption! phys=%lx idx=%lu >= total=%lu\n",
                phys, idx, total_page_count);
        for (;;) asm("cli; hlt");
    }

    free_list = page->next;
    global_free_count--;

    if (bitmap_test(idx)) {
        kprintf("[PMM] CRASH: page %lx (idx %lu) DOUBLE-ALLOCATED! free_list=%lx\n",
                phys, idx, (uint64_t)page->next);
        kprintf("[PMM] global_free_count=%lu total=%lu\n", global_free_count, total_page_count);
        for (;;) asm("cli; hlt");
    }
    bitmap_set(idx);

    /* Batch-refill per-CPU cache while we hold the global lock */
    cache_refill();

    spinlock_release(&pmm_global_lock, flags);
    kmemset((void*)PHYS_TO_VIRT(phys), 0, PAGE_SIZE);
    return phys;
}

uint64_t pmm_alloc_pages(uint32_t count) {
    if (count == 0) return 0;

    cpu_flags_t flags;
    spinlock_acquire(&pmm_global_lock, &flags);

    /* Flush all per-CPU caches so the bitmap reflects true free pages */
    for (int cpu = 0; cpu < MAX_CPUS; cpu++) {
        cpu_flags_t lflags;
        spinlock_acquire(&cpu_cache_lock[cpu], &lflags);
        int n = cpu_cache_count[cpu];
        for (int i = 0; i < n; i++) {
            uint64_t fphys = cpu_cache[cpu][i];
            uint64_t fidx = fphys / PAGE_SIZE;
            if (fidx < total_page_count) {
                bitmap_clear(fidx);
                global_free_count++;
                free_page_t* fp = (free_page_t*)PHYS_TO_VIRT(fphys);
                fp->next = free_list;
                free_list = fp;
            }
        }
        cpu_cache_count[cpu] = 0;
        spinlock_release(&cpu_cache_lock[cpu], lflags);
    }

    /* Scan bitmap for contiguous free region */
    uint64_t first = 0;
    uint32_t found = 0;
    for (uint64_t i = 0; i < total_page_count && found < count; i++) {
        if (!bitmap_test(i)) {
            if (found == 0) first = i;
            found++;
        } else {
            found = 0;
        }
    }

    if (found < count) { spinlock_release(&pmm_global_lock, flags); return 0; }

    for (uint32_t j = 0; j < count; j++) {
        bitmap_set(first + j);
        global_free_count--;
    }

    /* Single O(N) pass to remove allocated pages from free list */
    free_page_t** pp = &free_list;
    while (*pp) {
        free_page_t* cur = *pp;
        uint64_t pa = VIRT_TO_PHYS(cur);
        uint64_t pidx = pa / PAGE_SIZE;
        if (pidx >= first && pidx < first + count) {
            *pp = cur->next;
        } else {
            pp = &cur->next;
        }
    }

    spinlock_release(&pmm_global_lock, flags);

    for (uint32_t j = 0; j < count; j++)
        kmemset((void*)PHYS_TO_VIRT((first + j) * PAGE_SIZE), 0, PAGE_SIZE);

    return first * PAGE_SIZE;
}

void pmm_free_page(uint64_t phys_addr) {
    if (phys_addr == 0 || (phys_addr & 0xFFF)) return;

    /* Fast path: try per-CPU cache */
    if (cache_try_push(phys_addr))
        return;

    /* Cache full — flush half to global, then push */
    cpu_flags_t flags;
    spinlock_acquire(&pmm_global_lock, &flags);

    uint64_t idx = phys_addr / PAGE_SIZE;
    if (idx >= total_page_count) { spinlock_release(&pmm_global_lock, flags); return; }
    if (!bitmap_test(idx)) {
        kprintf("[PMM] Warning: double free detected: page %lx\n", phys_addr);
        spinlock_release(&pmm_global_lock, flags);
        return;
    }

    /* Flush half of our cache to global */
    cache_flush_half();

    /* Now free the caller's page to the now-emptied cache */
    bitmap_clear(idx);
    global_free_count++;

    int cpu = current_cpu();
    cpu_flags_t lflags;
    spinlock_acquire(&cpu_cache_lock[cpu], &lflags);
    int n = cpu_cache_count[cpu];
    cpu_cache[cpu][n] = phys_addr;
    cpu_cache_count[cpu] = n + 1;
    spinlock_release(&cpu_cache_lock[cpu], lflags);

    spinlock_release(&pmm_global_lock, flags);
}

void pmm_free_pages(uint64_t phys_addr, uint32_t count) {
    for (uint32_t i = 0; i < count; i++) {
        pmm_free_page(phys_addr + i * PAGE_SIZE);
    }
}

/* ------------------------------------------------------------------ */
/*  Initialisation                                                    */
/* ------------------------------------------------------------------ */
static void add_region_to_free_list(uint64_t start, uint64_t end) {
    if (start >= end) return;
    uint64_t s = (start + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
    uint64_t e = end & ~(PAGE_SIZE - 1);
    for (uint64_t phys = s; phys < e; phys += PAGE_SIZE) {
        uint64_t idx = phys / PAGE_SIZE;
        if (idx < total_page_count && !bitmap_test(idx)) {
            free_page_t* fp = (free_page_t*)PHYS_TO_VIRT(phys);
            fp->next = free_list;
            free_list = fp;
        }
    }
}

static void parse_mb_mmap(uint64_t mb_info) {
    (void)mb_info;
    hal_mmap_entry_t entries[MAX_MMAP_ENTRIES];
    int n = hal_get_mmap_entries(entries, MAX_MMAP_ENTRIES);
    if (n == 0) {
        add_region_to_free_list(1 * 1024 * 1024, total_memory);
        return;
    }
    for (int i = 0; i < n; i++) {
        if (entries[i].type == 1) {
            add_region_to_free_list(entries[i].start, entries[i].end);
        }
    }
}

err_t pmm_init(uint64_t mem_size_phys, uint64_t mb_info_phys) {
    spinlock_init(&pmm_global_lock, "pmm_global_lock");
    total_memory = mem_size_phys;
    total_page_count = mem_size_phys / PAGE_SIZE;

    /* Initialize per-CPU cache locks */
    for (int i = 0; i < MAX_CPUS; i++) {
        spinlock_init(&cpu_cache_lock[i], "pmm-cache");
        cpu_cache_count[i] = 0;
    }

    kprintf("[PMM] Total memory: %lu MB (%lu pages)\n",
            mem_size_phys / (1024 * 1024), total_page_count);

    uint64_t bitmap_size = (total_page_count + 7) / 8;
    bitmap_pages = (bitmap_size + PAGE_SIZE - 1) / PAGE_SIZE;
    bitmap_base = 0x10000;

    kmemset((void*)PHYS_TO_VIRT(bitmap_base), 0xFF, bitmap_pages * PAGE_SIZE);
    used_bitmap = (uint8_t*)(PHYS_TO_VIRT(bitmap_base));

    for (uint64_t i = 0; i < total_page_count; i++) {
        bitmap_clear(i);
    }
    global_free_count = total_page_count;

    pmm_mark_region_used(0, 0x1000);
    pmm_mark_region_used(0x7000, 0xB000);
    pmm_mark_region_used(0xA0000, 0x100000);
    pmm_mark_region_used(0x10000, 0x10000 + bitmap_pages * PAGE_SIZE);
    pmm_mark_region_used(mem_size_phys - 0x1000, mem_size_phys);

    extern uint64_t _kernel_end_phys;
    pmm_mark_region_used(0x100000, (uint64_t)&_kernel_end_phys);

    parse_mb_mmap(mb_info_phys);

    kprintf("[PMM] Free: %lu pages (%lu MB)\n",
            global_free_count, global_free_count * 4 / 1024);
    return ERR_OK;
}
