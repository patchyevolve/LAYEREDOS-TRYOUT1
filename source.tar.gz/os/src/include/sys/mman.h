#ifndef _SYS_MMAN_H
#define _SYS_MMAN_H

#define PROT_READ   0x1
#define PROT_WRITE  0x2
#define PROT_EXEC   0x4
#define PROT_NONE   0x0

#define MAP_SHARED      0x01
#define MAP_PRIVATE     0x02
#define MAP_FIXED       0x10
#define MAP_ANONYMOUS   0x20
#define MAP_POPULATE    0x8000

#define MAP_FAILED ((void*)-1)

#endif
