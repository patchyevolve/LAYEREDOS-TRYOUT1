#!/bin/bash
# OPERtur/TRY1 OS - Quick run/test script
set -e

MODE="${1:-run}"

case "$MODE" in
    run)
        make run
        ;;
    headless)
        make headless
        ;;
    test)
        make test
        ;;
    debug)
        make debug
        ;;
    monitor)
        make monitor
        ;;
    clean)
        make clean
        ;;
    rebuild)
        make rebuild
        ;;
    *)
        echo "Usage: $0 {run|headless|test|debug|monitor|clean|rebuild}"
        echo ""
        echo "  run       - Build and run in QEMU (default)"
        echo "  headless  - Headless mode (serial only)"
        echo "  test      - Automated headless test"
        echo "  debug     - Run with GDB stub on :1234"
        echo "  monitor   - Run with QEMU monitor"
        echo "  clean     - Clean build artifacts"
        echo "  rebuild   - Clean and rebuild"
        exit 1
        ;;
esac
